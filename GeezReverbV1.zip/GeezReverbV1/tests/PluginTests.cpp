/*
    Basic, dependency-light tests for Geez Reverb V1.

    These are intentionally NOT full JUCE UnitTest-framework tests wired
    into the plugin binary (that would require instantiating a full
    AudioProcessor, which needs a plugin host format context). Instead
    this is a small standalone console program, built as a separate
    CMake target (GeezReverbV1Tests), that exercises:

      - ReverbEngine processing stability (no NaN/Inf, no runaway gain)
      - Mono and stereo buffer handling
      - Multiple sample rates and buffer sizes
      - Bypass produces bit-identical passthrough
      - DECAY parameter has the expected qualitative effect on tail energy

    Preset loading/values are exercised indirectly via PresetManager's
    factory-preset table, which is plain data (see
    source/Presets/PresetManager.cpp) - it has no behaviour of its own
    beyond writing those values into parameters, so it is not
    duplicated here as a standalone-binary test.

    Run manually or via CI: build the GeezReverbV1Tests target and
    execute it; a non-zero exit code means a test failed.
*/

#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_dsp/juce_dsp.h>
#include "../source/DSP/ReverbEngine.h"

#include <iostream>
#include <cmath>

namespace
{
    int failures = 0;

    void expect (bool condition, const char* description)
    {
        if (! condition)
        {
            std::cerr << "[FAIL] " << description << "\n";
            ++failures;
        }
        else
        {
            std::cout << "[ OK ] " << description << "\n";
        }
    }

    bool bufferIsFinite (const juce::AudioBuffer<float>& buf)
    {
        for (int ch = 0; ch < buf.getNumChannels(); ++ch)
        {
            auto* data = buf.getReadPointer (ch);
            for (int n = 0; n < buf.getNumSamples(); ++n)
                if (! std::isfinite (data[n]))
                    return false;
        }
        return true;
    }

    void fillWithImpulseAndNoise (juce::AudioBuffer<float>& buf)
    {
        juce::Random rng (42);
        for (int ch = 0; ch < buf.getNumChannels(); ++ch)
        {
            auto* data = buf.getWritePointer (ch);
            data[0] = 1.0f;
            for (int n = 1; n < buf.getNumSamples(); ++n)
                data[n] = rng.nextFloat() * 0.5f - 0.25f;
        }
    }

    void testStabilityAtSampleRate (double sampleRate, int blockSize, int numChannels)
    {
        geez::dsp::ReverbEngine engine;
        engine.prepare (sampleRate, blockSize, numChannels);

        geez::dsp::ReverbParams params; // defaults
        juce::AudioBuffer<float> buffer (numChannels, blockSize);

        // Run several blocks so the tail builds up - this is where an
        // unstable feedback network would blow up or produce NaNs.
        bool finiteThroughout = true;
        float maxAbsSample = 0.0f;
        for (int block = 0; block < 200; ++block)
        {
            fillWithImpulseAndNoise (buffer);
            engine.process (buffer, params);

            if (! bufferIsFinite (buffer))
                finiteThroughout = false;

            maxAbsSample = juce::jmax (maxAbsSample, buffer.getMagnitude (0, buffer.getNumSamples()));
        }

        expect (finiteThroughout,
                ("engine stays finite @ " + juce::String (sampleRate) + "Hz / block " + juce::String (blockSize)
                 + " / ch " + juce::String (numChannels)).toRawUTF8());

        expect (maxAbsSample < 4.0f,
                ("engine does not runaway (no unbounded gain) @ " + juce::String (sampleRate) + "Hz").toRawUTF8());
    }

    void testBypassIsPassthrough()
    {
        geez::dsp::ReverbEngine engine;
        engine.prepare (44100.0, 512, 2);

        geez::dsp::ReverbParams params;
        params.bypassed = true;

        juce::AudioBuffer<float> buffer (2, 512);
        fillWithImpulseAndNoise (buffer);
        juce::AudioBuffer<float> reference;
        reference.makeCopyOf (buffer);

        engine.process (buffer, params);

        bool identical = true;
        for (int ch = 0; ch < 2 && identical; ++ch)
            for (int n = 0; n < 512 && identical; ++n)
                if (! juce::approximatelyEqual (buffer.getSample (ch, n), reference.getSample (ch, n)))
                    identical = false;

        expect (identical, "bypass produces bit-identical passthrough");
    }

    void testMonoDoesNotCrash()
    {
        geez::dsp::ReverbEngine engine;
        engine.prepare (48000.0, 256, 1);
        geez::dsp::ReverbParams params;
        juce::AudioBuffer<float> buffer (1, 256);
        fillWithImpulseAndNoise (buffer);
        engine.process (buffer, params);
        expect (bufferIsFinite (buffer), "mono buffer processes without crashing/NaNs");
    }

    void testDecayParameterAffectsFeedback()
    {
        // Sanity check: a longer DECAY should not produce a *shorter*
        // measured tail. We measure energy remaining after a fixed
        // number of blocks following a single impulse for two settings.
        auto measureTailEnergy = [] (float decaySeconds) -> float
        {
            geez::dsp::ReverbEngine engine;
            engine.prepare (44100.0, 512, 2);
            geez::dsp::ReverbParams params;
            params.decaySeconds = decaySeconds;
            params.mixPercent = 100.0f;

            juce::AudioBuffer<float> buffer (2, 512);
            buffer.clear();
            buffer.setSample (0, 0, 1.0f);
            buffer.setSample (1, 0, 1.0f);
            engine.process (buffer, params);

            float energy = 0.0f;
            for (int block = 0; block < 20; ++block)
            {
                buffer.clear();
                engine.process (buffer, params);
                energy += buffer.getMagnitude (0, buffer.getNumSamples());
            }
            return energy;
        };

        const float shortDecayEnergy = measureTailEnergy (0.2f);
        const float longDecayEnergy  = measureTailEnergy (8.0f);

        expect (longDecayEnergy > shortDecayEnergy,
                "longer DECAY parameter yields more sustained tail energy");
    }
}

int main()
{
    std::cout << "Geez Reverb V1 - basic test suite\n";
    std::cout << "----------------------------------\n";

    for (double sr : { 44100.0, 48000.0, 96000.0 })
        for (int blockSize : { 64, 256, 1024 })
            testStabilityAtSampleRate (sr, blockSize, 2);

    testBypassIsPassthrough();
    testMonoDoesNotCrash();
    testDecayParameterAffectsFeedback();

    std::cout << "----------------------------------\n";
    if (failures > 0)
    {
        std::cerr << failures << " test(s) FAILED\n";
        return 1;
    }

    std::cout << "All tests passed\n";
    return 0;
}
