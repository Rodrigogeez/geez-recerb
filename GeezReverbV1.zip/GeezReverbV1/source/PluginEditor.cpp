#include "PluginEditor.h"

namespace geez
{
    GeezReverbV1AudioProcessorEditor::GeezReverbV1AudioProcessorEditor (GeezReverbV1AudioProcessor& p)
        : juce::AudioProcessorEditor (&p), processor (p)
    {
        setLookAndFeel (&lookAndFeel);
        setResizable (false, false);
        setSize (960, 540); // ~16:9

        titleLabel.setFont (juce::Font (juce::FontOptions (26.0f, juce::Font::bold)));
        titleLabel.setColour (juce::Label::textColourId, GeezColours::textPrimary);
        addAndMakeVisible (titleLabel);

        versionLabel.setFont (juce::Font (juce::FontOptions (16.0f, juce::Font::bold)));
        versionLabel.setColour (juce::Label::textColourId, GeezColours::accent);
        addAndMakeVisible (versionLabel);

        addAndMakeVisible (prevPresetButton);
        addAndMakeVisible (nextPresetButton);
        addAndMakeVisible (presetBox);
        refreshPresetSelector();

        prevPresetButton.onClick = [this] { processor.presetManager.loadPrevious(); refreshPresetSelector(); };
        nextPresetButton.onClick = [this] { processor.presetManager.loadNext(); refreshPresetSelector(); };
        presetBox.onChange = [this]
        {
            const int idx = presetBox.getSelectedItemIndex();
            if (idx >= 0)
            {
                processor.presetManager.loadPreset (idx);
                refreshPresetSelector();
            }
        };

        bypassButton.setColour (juce::ToggleButton::textColourId, GeezColours::textPrimary);
        bypassAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (
            processor.apvts, ParamIDs::bypass, bypassButton);
        addAndMakeVisible (bypassButton);

        addAndMakeVisible (inputMeter);
        addAndMakeVisible (outputMeter);

        preDelayKnob = std::make_unique<KnobComponent> (processor.apvts, ParamIDs::preDelay, "PRE-DELAY", "ms");
        decayKnob    = std::make_unique<KnobComponent> (processor.apvts, ParamIDs::decay,    "DECAY",     "s");
        sizeKnob     = std::make_unique<KnobComponent> (processor.apvts, ParamIDs::size,     "SIZE",      "%");
        dampingKnob  = std::make_unique<KnobComponent> (processor.apvts, ParamIDs::damping,  "DAMPING",   "%");
        lowCutKnob   = std::make_unique<KnobComponent> (processor.apvts, ParamIDs::lowCut,   "LOW CUT",   "Hz");
        highCutKnob  = std::make_unique<KnobComponent> (processor.apvts, ParamIDs::highCut,  "HIGH CUT",  "Hz");
        widthKnob    = std::make_unique<KnobComponent> (processor.apvts, ParamIDs::width,    "WIDTH",     "%");
        mixKnob      = std::make_unique<KnobComponent> (processor.apvts, ParamIDs::mix,      "MIX",       "%");

        for (auto* k : { preDelayKnob.get(), decayKnob.get(), sizeKnob.get(), dampingKnob.get(),
                          lowCutKnob.get(), highCutKnob.get(), widthKnob.get(), mixKnob.get() })
            addAndMakeVisible (k);

        for (auto& name : processor.presetManager.getPresetNames())
        {
            auto* btn = presetButtons.add (new juce::TextButton (name.toUpperCase()));
            addAndMakeVisible (btn);
            btn->onClick = [this, name]
            {
                const int idx = processor.presetManager.getPresetNames().indexOf (name);
                processor.presetManager.loadPreset (idx);
                refreshPresetSelector();
            };
        }
        refreshPresetSelector();

        startTimerHz (30);
    }

    GeezReverbV1AudioProcessorEditor::~GeezReverbV1AudioProcessorEditor()
    {
        setLookAndFeel (nullptr);
    }

    void GeezReverbV1AudioProcessorEditor::refreshPresetSelector()
    {
        presetBox.clear (juce::dontSendNotification);
        int id = 1;
        for (auto& name : processor.presetManager.getPresetNames())
            presetBox.addItem (name, id++);
        presetBox.setSelectedItemIndex (processor.presetManager.getCurrentIndex(), juce::dontSendNotification);

        for (int i = 0; i < presetButtons.size(); ++i)
            presetButtons[i]->setToggleState (i == processor.presetManager.getCurrentIndex(),
                                               juce::dontSendNotification);
    }

    void GeezReverbV1AudioProcessorEditor::timerCallback()
    {
        inputMeter.setLevels (processor.getInputMeterLevel (0), processor.getInputMeterLevel (1));
        outputMeter.setLevels (processor.getOutputMeterLevel (0), processor.getOutputMeterLevel (1));
    }

    void GeezReverbV1AudioProcessorEditor::paint (juce::Graphics& g)
    {
        paintBurgundyTexture (g, getLocalBounds());

        // Header strip
        auto header = getLocalBounds().removeFromTop (64);
        g.setColour (GeezColours::panel);
        g.fillRect (header);
    }

    void GeezReverbV1AudioProcessorEditor::resized()
    {
        auto area = getLocalBounds();

        // --- Header ---
        auto header = area.removeFromTop (64).reduced (16, 10);
        titleLabel.setBounds (header.removeFromLeft (280));
        versionLabel.setBounds (header.removeFromLeft (40));

        auto presetNav = header.removeFromLeft (260);
        prevPresetButton.setBounds (presetNav.removeFromLeft (36));
        nextPresetButton.setBounds (presetNav.removeFromRight (36));
        presetBox.setBounds (presetNav.reduced (4, 6));

        bypassButton.setBounds (header.removeFromRight (110).reduced (0, 6));

        area.reduce (24, 16);

        // --- Meters (left/right columns) ---
        auto inputArea  = area.removeFromLeft (80);
        auto outputArea = area.removeFromRight (80);
        inputMeter.setBounds (inputArea.removeFromTop (280));
        outputMeter.setBounds (outputArea.removeFromTop (280));

        area.removeFromLeft (12);
        area.removeFromRight (12);

        // --- Knob grid: 4 columns x 2 rows ---
        auto knobArea = area.removeFromTop (300);
        auto row1 = knobArea.removeFromTop (150);
        auto row2 = knobArea;

        const int colWidth = row1.getWidth() / 4;
        for (auto* k : { preDelayKnob.get(), decayKnob.get(), sizeKnob.get(), dampingKnob.get() })
            k->setBounds (row1.removeFromLeft (colWidth).reduced (8));

        for (auto* k : { lowCutKnob.get(), highCutKnob.get(), widthKnob.get(), mixKnob.get() })
            k->setBounds (row2.removeFromLeft (colWidth).reduced (8));

        // --- Preset row ---
        area.removeFromTop (16);
        auto presetRow = area.removeFromTop (44);
        const int btnWidth = presetRow.getWidth() / juce::jmax (1, presetButtons.size());
        for (auto* btn : presetButtons)
            btn->setBounds (presetRow.removeFromLeft (btnWidth).reduced (4));
    }
}
