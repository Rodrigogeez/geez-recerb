#pragma once

#include <juce_audio_processors/juce_audio_processors.h>
#include <map>
#include <vector>

namespace geez
{
    /** Simple, dependency-free preset system: each preset is just a map
        of parameter ID -> value, applied on top of the existing 8
        parameters. No new parameters are ever introduced by a preset. */
    class PresetManager
    {
    public:
        explicit PresetManager (juce::AudioProcessorValueTreeState& stateIn);

        const juce::StringArray& getPresetNames() const noexcept { return presetNames; }
        int getCurrentIndex() const noexcept { return currentIndex; }

        void loadPreset (int index);
        void loadNext();
        void loadPrevious();

    private:
        struct Preset
        {
            juce::String name;
            std::map<juce::String, float> values;
        };

        juce::AudioProcessorValueTreeState& apvts;
        std::vector<Preset> presets;
        juce::StringArray presetNames;
        int currentIndex = 0;

        void buildFactoryPresets();
    };
}
