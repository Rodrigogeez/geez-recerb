#include "PresetManager.h"
#include "../PluginProcessor.h"

namespace geez
{
    PresetManager::PresetManager (juce::AudioProcessorValueTreeState& stateIn)
        : apvts (stateIn)
    {
        buildFactoryPresets();
    }

    void PresetManager::buildFactoryPresets()
    {
        using namespace ParamIDs;

        presets.push_back ({ "Default", {
            { preDelay, 20.0f }, { decay, 2.80f }, { size, 65.0f }, { damping, 60.0f },
            { lowCut, 100.0f }, { highCut, 8000.0f }, { width, 100.0f }, { mix, 35.0f }
        }});

        // Short pre-delay, moderate decay, generous high cut roll-off so the
        // tail sits behind a vocal without smearing consonants.
        presets.push_back ({ "Vocal", {
            { preDelay, 15.0f }, { decay, 1.60f }, { size, 45.0f }, { damping, 55.0f },
            { lowCut, 150.0f }, { highCut, 6500.0f }, { width, 90.0f }, { mix, 22.0f }
        }});

        // Small/medium room: short decay, small size, higher damping so
        // the tail dies quickly and stays tight.
        presets.push_back ({ "Room", {
            { preDelay, 5.0f }, { decay, 0.90f }, { size, 30.0f }, { damping, 45.0f },
            { lowCut, 120.0f }, { highCut, 9000.0f }, { width, 100.0f }, { mix, 30.0f }
        }});

        // Large hall: long pre-delay and decay, large size, low damping so
        // highs persist longer into the tail.
        presets.push_back ({ "Hall", {
            { preDelay, 35.0f }, { decay, 4.80f }, { size, 90.0f }, { damping, 35.0f },
            { lowCut, 80.0f }, { highCut, 10000.0f }, { width, 120.0f }, { mix, 40.0f }
        }});

        // Plate character: near-zero pre-delay, dense/bright, narrower
        // width than a hall (plates are a mono/near-mono source spread
        // electronically, not a large physical space).
        presets.push_back ({ "Plate", {
            { preDelay, 0.0f }, { decay, 2.20f }, { size, 55.0f }, { damping, 25.0f },
            { lowCut, 100.0f }, { highCut, 12000.0f }, { width, 70.0f }, { mix, 33.0f }
        }});

        for (auto& p : presets)
            presetNames.add (p.name);
    }

    void PresetManager::loadPreset (int index)
    {
        if (index < 0 || index >= (int) presets.size())
            return;

        currentIndex = index;
        const auto& preset = presets[(size_t) index];

        for (auto& [paramID, value] : preset.values)
        {
            if (auto* param = apvts.getParameter (paramID))
            {
                const auto normalised = param->getNormalisableRange().convertTo0to1 (value);
                param->setValueNotifyingHost (normalised);
            }
        }
    }

    void PresetManager::loadNext()
    {
        loadPreset ((currentIndex + 1) % (int) presets.size());
    }

    void PresetManager::loadPrevious()
    {
        loadPreset ((currentIndex - 1 + (int) presets.size()) % (int) presets.size());
    }
}
