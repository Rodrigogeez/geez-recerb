#pragma once

#include <juce_audio_processors/juce_audio_processors.h>
#include "DSP/ReverbEngine.h"
#include "Presets/PresetManager.h"
#include "Licensing/LicenseManager.h"

namespace geez
{
    /** Stable parameter IDs. Do not change these once shipped - see
        section 11/23 of the product spec: automation in DAW projects is
        tied to these strings, and existing user sessions would break. */
    namespace ParamIDs
    {
        static const juce::String preDelay = "preDelay";
        static const juce::String decay    = "decay";
        static const juce::String size     = "size";
        static const juce::String damping  = "damping";
        static const juce::String lowCut   = "lowCut";
        static const juce::String highCut  = "highCut";
        static const juce::String width    = "width";
        static const juce::String mix      = "mix";
        static const juce::String bypass   = "bypass";
    }

    class GeezReverbV1AudioProcessor : public juce::AudioProcessor
    {
    public:
        GeezReverbV1AudioProcessor();
        ~GeezReverbV1AudioProcessor() override = default;

        void prepareToPlay (double sampleRate, int samplesPerBlock) override;
        void releaseResources() override;
        bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
        void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

        juce::AudioProcessorEditor* createEditor() override;
        bool hasEditor() const override { return true; }

        const juce::String getName() const override { return "Geez Reverb V1"; }
        bool acceptsMidi() const override  { return false; }
        bool producesMidi() const override { return false; }
        bool isMidiEffect() const override { return false; }
        double getTailLengthSeconds() const override { return 10.0; }

        int getNumPrograms() override { return 1; }
        int getCurrentProgram() override { return 0; }
        void setCurrentProgram (int) override {}
        const juce::String getProgramName (int) override { return {}; }
        void changeProgramName (int, const juce::String&) override {}

        void getStateInformation (juce::MemoryBlock& destData) override;
        void setStateInformation (const void* data, int sizeInBytes) override;

        static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

        juce::AudioProcessorValueTreeState apvts;
        PresetManager presetManager;
        LicenseManager licenseManager;

        float getInputMeterLevel (int channel) const  { return reverbEngine.getInputLevel (channel); }
        float getOutputMeterLevel (int channel) const { return reverbEngine.getOutputLevel (channel); }

    private:
        geez::dsp::ReverbEngine reverbEngine;

        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (GeezReverbV1AudioProcessor)
    };
}
