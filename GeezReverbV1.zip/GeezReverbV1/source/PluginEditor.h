#pragma once

#include <juce_audio_processors/juce_audio_processors.h>
#include "PluginProcessor.h"
#include "GUI/GeezLookAndFeel.h"
#include "GUI/KnobComponent.h"
#include "GUI/MeterComponent.h"

namespace geez
{
    class GeezReverbV1AudioProcessorEditor : public juce::AudioProcessorEditor,
                                              private juce::Timer
    {
    public:
        explicit GeezReverbV1AudioProcessorEditor (GeezReverbV1AudioProcessor&);
        ~GeezReverbV1AudioProcessorEditor() override;

        void paint (juce::Graphics&) override;
        void resized() override;

    private:
        GeezReverbV1AudioProcessor& processor;
        GeezLookAndFeel lookAndFeel;

        // Header
        juce::Label titleLabel { {}, "GEEZ REVERB" };
        juce::Label versionLabel { {}, "V1" };
        juce::TextButton prevPresetButton { "<" }, nextPresetButton { ">" };
        juce::ComboBox presetBox;
        juce::ToggleButton bypassButton { "BYPASS" };
        std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> bypassAttachment;

        // Meters
        MeterComponent inputMeter { "INPUT" };
        MeterComponent outputMeter { "OUTPUT" };

        // 8 main knobs
        std::unique_ptr<KnobComponent> preDelayKnob, decayKnob, sizeKnob, dampingKnob,
                                        lowCutKnob, highCutKnob, widthKnob, mixKnob;

        // Preset row buttons
        juce::OwnedArray<juce::TextButton> presetButtons;

        void refreshPresetSelector();
        void timerCallback() override;

        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (GeezReverbV1AudioProcessorEditor)
    };
}
