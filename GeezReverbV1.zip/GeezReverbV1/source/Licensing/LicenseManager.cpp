#include "LicenseManager.h"

// Intentionally empty. All members of LicenseManager are currently
// trivial and defined inline in the header. This .cpp exists so the
// Licensing layer has its own translation unit ready for future,
// non-trivial implementation (e.g. server calls, serial validation)
// without needing to touch build files again.
