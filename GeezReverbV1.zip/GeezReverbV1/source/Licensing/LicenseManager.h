#pragma once

#include <juce_core/juce_core.h>

namespace geez
{
    /**
        Placeholder licensing layer.

        NOTHING in this class talks to a network, checks a serial, or
        gates DSP/GUI functionality. Its only job right now is to exist
        as a stable seam so that a future version can plug in real
        activation logic (serial entry, online activation, a license
        server call, and reporting a LicenseStatus) without touching
        ReverbEngine, PluginProcessor's audio path, or the GUI.

        Per the product spec (section 14): no license server, serial,
        payment, or online activation is implemented in V1. The plugin
        always reports DevelopmentMode and is always fully functional.
    */
    enum class LicenseStatus
    {
        DevelopmentMode,  // V1: always this value.
        Unlicensed,       // reserved for future use
        Licensed,         // reserved for future use
        Expired           // reserved for future use
    };

    class LicenseManager
    {
    public:
        LicenseManager() = default;

        LicenseStatus getStatus() const noexcept { return LicenseStatus::DevelopmentMode; }
        bool isFullyFunctional() const noexcept { return true; } // always true in V1

        // Reserved for future implementation - intentionally not called
        // from anywhere in V1.
        bool activateWithSerial (const juce::String& /*serial*/) { return false; }
        void deactivate() {}
    };
}
