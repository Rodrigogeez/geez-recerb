#pragma once

#include <juce_gui_basics/juce_gui_basics.h>
#include "GeezLookAndFeel.h"
#include <functional>

namespace geez
{
    /** Simple stereo L/R peak meter. The owner (editor) is responsible for
        calling setLevels() periodically (e.g. from a juce::Timer) - this
        component does no polling itself, keeping it a passive view. */
    class MeterComponent : public juce::Component
    {
    public:
        explicit MeterComponent (juce::String titleText) : title (std::move (titleText)) {}

        void setLevels (float leftLevel, float rightLevel)
        {
            // Light smoothing so the meter doesn't flicker frame to frame.
            left  = juce::jmax (leftLevel,  left * 0.7f);
            right = juce::jmax (rightLevel, right * 0.7f);
            repaint();
        }

        void paint (juce::Graphics& g) override
        {
            auto area = getLocalBounds();

            g.setColour (GeezColours::textPrimary);
            g.setFont (juce::Font (juce::FontOptions (13.0f, juce::Font::bold)));
            g.drawText (title, area.removeFromTop (20), juce::Justification::centred);

            auto labels = area.removeFromBottom (18);
            g.setColour (GeezColours::textSecondary);
            g.setFont (juce::Font (juce::FontOptions (11.0f)));
            g.drawText ("L", labels.removeFromLeft (labels.getWidth() / 2), juce::Justification::centred);
            g.drawText ("R", labels, juce::Justification::centred);

            auto bars = area.reduced (4);
            auto leftBar  = bars.removeFromLeft (bars.getWidth() / 2).reduced (3, 0);
            auto rightBar = bars.reduced (3, 0);

            drawBar (g, leftBar, left);
            drawBar (g, rightBar, right);
        }

    private:
        juce::String title;
        float left = 0.0f, right = 0.0f;

        static void drawBar (juce::Graphics& g, juce::Rectangle<int> bounds, float level)
        {
            g.setColour (GeezColours::panel);
            g.fillRect (bounds);

            const float db = juce::Decibels::gainToDecibels (juce::jmax (level, 0.0001f));
            const float normalised = juce::jlimit (0.0f, 1.0f, (db + 60.0f) / 66.0f); // -60..+6 dB range

            auto filled = bounds.withTop (bounds.getBottom() - (int) (bounds.getHeight() * normalised));

            juce::ColourGradient grad (juce::Colours::limegreen, bounds.getBottomLeft().toFloat(),
                                        juce::Colours::orangered, bounds.getTopLeft().toFloat(), false);
            grad.addColour (0.75, juce::Colours::gold);
            g.setGradientFill (grad);
            g.fillRect (filled);

            g.setColour (GeezColours::knobOutline);
            g.drawRect (bounds, 1);
        }
    };
}
