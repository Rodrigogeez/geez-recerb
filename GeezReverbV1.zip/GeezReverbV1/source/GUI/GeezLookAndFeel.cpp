#include "GeezLookAndFeel.h"

namespace geez
{
    GeezLookAndFeel::GeezLookAndFeel()
    {
        setColour (juce::Slider::thumbColourId, GeezColours::textPrimary);
        setColour (juce::Slider::rotarySliderFillColourId, GeezColours::accent);
        setColour (juce::Slider::rotarySliderOutlineColourId, GeezColours::knobOutline);
        setColour (juce::Label::textColourId, GeezColours::textPrimary);
        setColour (juce::TextButton::buttonColourId, GeezColours::panel);
        setColour (juce::TextButton::buttonOnColourId, GeezColours::accent);
        setColour (juce::TextButton::textColourOnId, GeezColours::textPrimary);
        setColour (juce::TextButton::textColourOffId, GeezColours::textSecondary);
        setColour (juce::ComboBox::backgroundColourId, GeezColours::panel);
        setColour (juce::ComboBox::textColourId, GeezColours::textPrimary);
    }

    juce::Font GeezLookAndFeel::getLabelFont (juce::Label&)
    {
        return juce::Font (juce::FontOptions (13.0f, juce::Font::bold));
    }

    void GeezLookAndFeel::drawRotarySlider (juce::Graphics& g, int x, int y, int width, int height,
                                             float sliderPos, float rotaryStartAngle, float rotaryEndAngle,
                                             juce::Slider&)
    {
        auto bounds = juce::Rectangle<int> (x, y, width, height).toFloat().reduced (4.0f);
        const auto radius = juce::jmin (bounds.getWidth(), bounds.getHeight()) * 0.5f;
        const auto centre = bounds.getCentre();
        const auto angle = rotaryStartAngle + sliderPos * (rotaryEndAngle - rotaryStartAngle);

        // Outer dark ring
        g.setColour (GeezColours::knobOutline);
        g.fillEllipse (bounds);

        // Value arc track
        juce::Path track;
        track.addCentredArc (centre.x, centre.y, radius - 3.0f, radius - 3.0f, 0.0f,
                              rotaryStartAngle, rotaryEndAngle, true);
        g.setColour (GeezColours::panel.brighter (0.15f));
        g.strokePath (track, juce::PathStrokeType (3.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        juce::Path valueArc;
        valueArc.addCentredArc (centre.x, centre.y, radius - 3.0f, radius - 3.0f, 0.0f,
                                 rotaryStartAngle, angle, true);
        g.setColour (GeezColours::accent);
        g.strokePath (valueArc, juce::PathStrokeType (3.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        // Knob body (graphite) with a discreet shadow and premium-but-flat gradient
        auto bodyBounds = bounds.reduced (radius * 0.16f);
        juce::ColourGradient grad (GeezColours::knobBody.brighter (0.15f), bodyBounds.getTopLeft(),
                                    GeezColours::knobBody.darker (0.35f), bodyBounds.getBottomRight(), false);
        g.setGradientFill (grad);
        g.fillEllipse (bodyBounds);
        g.setColour (GeezColours::knobOutline);
        g.drawEllipse (bodyBounds, 1.5f);

        // White pointer indicator
        const float indicatorRadius = bodyBounds.getWidth() * 0.5f;
        juce::Point<float> indicatorEnd (
            centre.x + indicatorRadius * 0.72f * std::cos (angle - juce::MathConstants<float>::halfPi),
            centre.y + indicatorRadius * 0.72f * std::sin (angle - juce::MathConstants<float>::halfPi));
        g.setColour (GeezColours::textPrimary);
        g.drawLine ({ centre, indicatorEnd }, 2.2f);

        // Small burgundy accent dot at the base of the indicator travel
        juce::Point<float> accentDot (
            centre.x + indicatorRadius * 0.95f * std::cos (rotaryEndAngle - juce::MathConstants<float>::halfPi),
            centre.y + indicatorRadius * 0.95f * std::sin (rotaryEndAngle - juce::MathConstants<float>::halfPi));
        g.setColour (GeezColours::accent);
        g.fillEllipse (juce::Rectangle<float> (4.0f, 4.0f).withCentre (accentDot));
    }

    void GeezLookAndFeel::drawButtonBackground (juce::Graphics& g, juce::Button& button, const juce::Colour&,
                                                 bool isHighlighted, bool isDown)
    {
        auto bounds = button.getLocalBounds().toFloat().reduced (1.0f);
        auto colour = button.getToggleState() ? GeezColours::accent : GeezColours::panel;
        if (isHighlighted) colour = colour.brighter (0.1f);
        if (isDown)         colour = colour.darker (0.1f);

        g.setColour (colour);
        g.fillRoundedRectangle (bounds, 4.0f);
        g.setColour (GeezColours::knobOutline);
        g.drawRoundedRectangle (bounds, 4.0f, 1.0f);
    }

    void paintBurgundyTexture (juce::Graphics& g, juce::Rectangle<int> area)
    {
        g.setColour (GeezColours::background);
        g.fillRect (area);

        // Deterministic pseudo-random irregular thin lines, very low
        // opacity, evoking a woven/denim texture without ever competing
        // with the controls drawn on top of it.
        juce::Random rng (1234); // fixed seed -> stable look across opens
        g.saveState();
        g.reduceClipRegion (area);

        for (int i = 0; i < area.getWidth() / 3; ++i)
        {
            const float x = (float) area.getX() + (float) i * 3.0f + rng.nextFloat() * 2.0f;
            const float jitter = rng.nextFloat() * 6.0f - 3.0f;
            juce::Path line;
            line.startNewSubPath (x, (float) area.getY());
            line.lineTo (x + jitter, (float) area.getBottom());
            g.setColour (juce::Colours::black.withAlpha (0.035f + rng.nextFloat() * 0.02f));
            g.strokePath (line, juce::PathStrokeType (1.0f));
        }

        g.restoreState();
    }
}
