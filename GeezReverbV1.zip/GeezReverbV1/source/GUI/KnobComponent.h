#pragma once

#include <juce_audio_processors/juce_audio_processors.h>
#include "GeezLookAndFeel.h"

namespace geez
{
    /** Name label + rotary knob + live value label, matching the layout
        in spec section 9 ("PRE-DELAY / [KNOB] / 20 ms"). */
    class KnobComponent : public juce::Component
    {
    public:
        KnobComponent (juce::AudioProcessorValueTreeState& apvts, const juce::String& paramID,
                        const juce::String& displayName, const juce::String& suffix)
        {
            nameLabel.setText (displayName, juce::dontSendNotification);
            nameLabel.setJustificationType (juce::Justification::centred);
            nameLabel.setColour (juce::Label::textColourId, GeezColours::textPrimary);
            addAndMakeVisible (nameLabel);

            slider.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
            slider.setTextBoxStyle (juce::Slider::NoTextBox, true, 0, 0);
            slider.setRotaryParameters (juce::MathConstants<float>::pi * 1.2f,
                                         juce::MathConstants<float>::pi * 2.8f, true);
            addAndMakeVisible (slider);

            valueLabel.setJustificationType (juce::Justification::centred);
            valueLabel.setColour (juce::Label::textColourId, GeezColours::textSecondary);
            addAndMakeVisible (valueLabel);

            attachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (
                apvts, paramID, slider);

            valueSuffix = suffix;
            slider.onValueChange = [this] { updateValueLabel(); };
            updateValueLabel();
        }

        void resized() override
        {
            auto area = getLocalBounds();
            nameLabel.setBounds (area.removeFromTop (18));
            valueLabel.setBounds (area.removeFromBottom (18));
            slider.setBounds (area.reduced (4));
        }

    private:
        juce::Label nameLabel, valueLabel;
        juce::Slider slider;
        juce::String valueSuffix;
        std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attachment;

        void updateValueLabel()
        {
            // Decimal precision matches the parameter's step size roughly:
            // ms/Hz/% -> 0-1 decimals, seconds -> 2 decimals.
            const double v = slider.getValue();
            juce::String text;
            if (valueSuffix == "s")
                text = juce::String (v, 2) + " " + valueSuffix;
            else if (valueSuffix == "Hz" && v >= 1000.0)
                text = juce::String (v / 1000.0, 2) + " kHz";
            else
                text = juce::String (v, (valueSuffix == "ms" || valueSuffix == "%") ? 0 : 1) + " " + valueSuffix;
            valueLabel.setText (text, juce::dontSendNotification);
        }
    };
}
