#pragma once

#include <juce_gui_basics/juce_gui_basics.h>

namespace geez
{
    /** Brand palette, per section 7 of the product spec. Centralised here
        so every component (editor, knobs, meters, preset bar) pulls from
        the same source instead of hardcoding colours. */
    namespace GeezColours
    {
        static const juce::Colour background   { 0xff2a0f16 }; // deep burgundy
        static const juce::Colour panel        { 0xff141014 }; // near-black
        static const juce::Colour knobBody     { 0xff5a5a5e }; // graphite
        static const juce::Colour knobOutline  { 0xff0d0d0d }; // black
        static const juce::Colour accent       { 0xffb23a52 }; // lighter burgundy
        static const juce::Colour textPrimary  { 0xfff2f2f2 }; // white
        static const juce::Colour textSecondary{ 0xffbdbdbd }; // light grey
    }

    class GeezLookAndFeel : public juce::LookAndFeel_V4
    {
    public:
        GeezLookAndFeel();

        void drawRotarySlider (juce::Graphics&, int x, int y, int width, int height,
                                float sliderPosProportional, float rotaryStartAngle,
                                float rotaryEndAngle, juce::Slider&) override;

        void drawButtonBackground (juce::Graphics&, juce::Button&, const juce::Colour& backgroundColour,
                                    bool shouldDrawButtonAsHighlighted, bool shouldDrawButtonAsDown) override;

        juce::Font getLabelFont (juce::Label&) override;
    };

    /** Very subtle irregular-line texture, drawn once into a cached image
        and tiled behind the panel so it reads as part of the material
        rather than an overlay. Opacity is intentionally low (see spec 8). */
    void paintBurgundyTexture (juce::Graphics& g, juce::Rectangle<int> area);
}
