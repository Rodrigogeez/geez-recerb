#include "PluginProcessor.h"
#include "PluginEditor.h"

namespace geez
{
    GeezReverbV1AudioProcessor::GeezReverbV1AudioProcessor()
        : AudioProcessor (BusesProperties()
              .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
              .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
          apvts (*this, nullptr, "PARAMETERS", createParameterLayout()),
          presetManager (apvts)
    {
    }

    juce::AudioProcessorValueTreeState::ParameterLayout GeezReverbV1AudioProcessor::createParameterLayout()
    {
        std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

        params.push_back (std::make_unique<juce::AudioParameterFloat>(
            juce::ParameterID { ParamIDs::preDelay, 1 }, "Pre-Delay",
            juce::NormalisableRange<float> (0.0f, 200.0f, 0.1f), 20.0f,
            juce::AudioParameterFloatAttributes().withLabel ("ms")));

        params.push_back (std::make_unique<juce::AudioParameterFloat>(
            juce::ParameterID { ParamIDs::decay, 1 }, "Decay",
            juce::NormalisableRange<float> (0.1f, 10.0f, 0.01f, 0.5f), 2.8f,
            juce::AudioParameterFloatAttributes().withLabel ("s")));

        params.push_back (std::make_unique<juce::AudioParameterFloat>(
            juce::ParameterID { ParamIDs::size, 1 }, "Size",
            juce::NormalisableRange<float> (0.0f, 100.0f, 0.1f), 65.0f,
            juce::AudioParameterFloatAttributes().withLabel ("%")));

        params.push_back (std::make_unique<juce::AudioParameterFloat>(
            juce::ParameterID { ParamIDs::damping, 1 }, "Damping",
            juce::NormalisableRange<float> (0.0f, 100.0f, 0.1f), 60.0f,
            juce::AudioParameterFloatAttributes().withLabel ("%")));

        params.push_back (std::make_unique<juce::AudioParameterFloat>(
            juce::ParameterID { ParamIDs::lowCut, 1 }, "Low Cut",
            juce::NormalisableRange<float> (20.0f, 500.0f, 0.1f, 0.4f), 100.0f,
            juce::AudioParameterFloatAttributes().withLabel ("Hz")));

        params.push_back (std::make_unique<juce::AudioParameterFloat>(
            juce::ParameterID { ParamIDs::highCut, 1 }, "High Cut",
            juce::NormalisableRange<float> (2000.0f, 20000.0f, 1.0f, 0.4f), 8000.0f,
            juce::AudioParameterFloatAttributes().withLabel ("Hz")));

        params.push_back (std::make_unique<juce::AudioParameterFloat>(
            juce::ParameterID { ParamIDs::width, 1 }, "Width",
            juce::NormalisableRange<float> (0.0f, 150.0f, 0.1f), 100.0f,
            juce::AudioParameterFloatAttributes().withLabel ("%")));

        params.push_back (std::make_unique<juce::AudioParameterFloat>(
            juce::ParameterID { ParamIDs::mix, 1 }, "Mix",
            juce::NormalisableRange<float> (0.0f, 100.0f, 0.1f), 35.0f,
            juce::AudioParameterFloatAttributes().withLabel ("%")));

        params.push_back (std::make_unique<juce::AudioParameterBool>(
            juce::ParameterID { ParamIDs::bypass, 1 }, "Bypass", false));

        return { params.begin(), params.end() };
    }

    void GeezReverbV1AudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
    {
        reverbEngine.prepare (sampleRate, samplesPerBlock, 2);
    }

    void GeezReverbV1AudioProcessor::releaseResources()
    {
        reverbEngine.reset();
    }

    bool GeezReverbV1AudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
    {
        const auto out = layouts.getMainOutputChannelSet();
        if (out != juce::AudioChannelSet::mono() && out != juce::AudioChannelSet::stereo())
            return false;

        // Input must be mono or stereo, and never wider than the output
        // (mono in -> stereo out is allowed; stereo in -> mono out is not).
        const auto in = layouts.getMainInputChannelSet();
        if (in != juce::AudioChannelSet::mono() && in != juce::AudioChannelSet::stereo())
            return false;

        return in.size() <= out.size();
    }

    void GeezReverbV1AudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
    {
        juce::ScopedNoDenormals noDenormals;
        midi.clear();

        const int numOutChannels = getTotalNumOutputChannels();
        const int numInChannels  = getTotalNumInputChannels();

        // Mono input -> stereo output: duplicate the mono signal into the
        // right channel before it reaches the (always-stereo) reverb engine.
        if (numInChannels == 1 && numOutChannels == 2)
            buffer.copyFrom (1, 0, buffer, 0, 0, buffer.getNumSamples());

        for (int ch = numInChannels; ch < numOutChannels; ++ch)
            buffer.clear (ch, 0, buffer.getNumSamples());

        geez::dsp::ReverbParams p;
        p.preDelayMs   = apvts.getRawParameterValue (ParamIDs::preDelay)->load();
        p.decaySeconds = apvts.getRawParameterValue (ParamIDs::decay)->load();
        p.sizePercent  = apvts.getRawParameterValue (ParamIDs::size)->load();
        p.dampingPct   = apvts.getRawParameterValue (ParamIDs::damping)->load();
        p.lowCutHz     = apvts.getRawParameterValue (ParamIDs::lowCut)->load();
        p.highCutHz    = apvts.getRawParameterValue (ParamIDs::highCut)->load();
        p.widthPercent = apvts.getRawParameterValue (ParamIDs::width)->load();
        p.mixPercent   = apvts.getRawParameterValue (ParamIDs::mix)->load();
        p.bypassed     = apvts.getRawParameterValue (ParamIDs::bypass)->load() > 0.5f;

        reverbEngine.process (buffer, p);
    }

    juce::AudioProcessorEditor* GeezReverbV1AudioProcessor::createEditor()
    {
        return new GeezReverbV1AudioProcessorEditor (*this);
    }

    void GeezReverbV1AudioProcessor::getStateInformation (juce::MemoryBlock& destData)
    {
        auto state = apvts.copyState();
        std::unique_ptr<juce::XmlElement> xml (state.createXml());
        copyXmlToBinary (*xml, destData);
    }

    void GeezReverbV1AudioProcessor::setStateInformation (const void* data, int sizeInBytes)
    {
        std::unique_ptr<juce::XmlElement> xml (getXmlFromBinary (data, sizeInBytes));
        if (xml != nullptr && xml->hasTagName (apvts.state.getType()))
            apvts.replaceState (juce::ValueTree::fromXml (*xml));
    }
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new geez::GeezReverbV1AudioProcessor();
}
