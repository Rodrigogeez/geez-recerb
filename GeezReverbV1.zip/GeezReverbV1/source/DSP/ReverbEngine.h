#pragma once

#include <juce_dsp/juce_dsp.h>
#include "CombFilter.h"
#include "AllpassFilter.h"
#include <array>

namespace geez::dsp
{
    /** Parameter snapshot passed into the engine once per block. All units
        are the real-world units documented in the plugin spec (ms, s, Hz, %).
        No allocation happens anywhere in ReverbEngine::process(). */
    struct ReverbParams
    {
        float preDelayMs   = 20.0f;   // 0-200
        float decaySeconds = 2.8f;    // 0.1-10.0
        float sizePercent  = 65.0f;   // 0-100
        float dampingPct   = 60.0f;   // 0-100
        float lowCutHz     = 100.0f;  // 20-500
        float highCutHz    = 8000.0f; // 2000-20000
        float widthPercent = 100.0f;  // 0-150
        float mixPercent   = 35.0f;   // 0-100
        bool  bypassed     = false;
    };

    class ReverbEngine
    {
    public:
        static constexpr int kNumCombs   = 8; // 4 per channel base tuning, cross-offset for stereo
        static constexpr int kNumAllpass = 4;

        void prepare (double sampleRate, int samplesPerBlock, int numChannels);
        void reset();

        // In-place processing. buffer must be a stereo (or mono->already
        // duplicated to stereo by the caller) JUCE AudioBuffer<float>.
        void process (juce::AudioBuffer<float>& buffer, const ReverbParams& params);

        // Post-processing metering, read by the GUI on the message thread.
        float getInputLevel (int channel) const noexcept  { return inputLevel[(size_t) channel].load(); }
        float getOutputLevel (int channel) const noexcept { return outputLevel[(size_t) channel].load(); }

    private:
        double sampleRate = 44100.0;

        // Predelay: single shared delay line per channel, sized for the max 200ms.
        juce::dsp::DelayLine<float, juce::dsp::DelayLineInterpolationTypes::Linear> preDelayLine[2] { {0}, {0} };

        // Base delay lengths (ms) for the comb bank, tuned to avoid common
        // integer ratios (reduces metallic ringing / audible echo repeats).
        // Left and right channels use different offsets so the tail is
        // decorrelated between channels (part of the stereo image), not a
        // simple duplicate.
        static constexpr std::array<float, 4> baseCombMsL { 29.7f, 37.1f, 41.3f, 47.9f };
        static constexpr std::array<float, 4> baseCombMsR { 31.3f, 39.5f, 43.7f, 50.1f };
        static constexpr std::array<float, kNumAllpass> allpassMsL { 5.0f, 1.7f, 3.9f, 2.3f };
        static constexpr std::array<float, kNumAllpass> allpassMsR { 5.6f, 1.4f, 4.4f, 2.0f };

        std::array<CombFilter, 4> combsL, combsR;
        std::array<AllpassFilter, kNumAllpass> allpassL, allpassR;

        juce::dsp::IIR::Filter<float> lowCutFilter[2];
        juce::dsp::IIR::Filter<float> highCutFilter[2];
        juce::dsp::IIR::Coefficients<float>::Ptr lowCutCoeffs, highCutCoeffs;
        float lastLowCutHz = -1.0f, lastHighCutHz = -1.0f;

        std::array<std::atomic<float>, 2> inputLevel  { { 0.0f, 0.0f } };
        std::array<std::atomic<float>, 2> outputLevel { { 0.0f, 0.0f } };

        float computeFeedbackForDecay (float decaySeconds, float delayMs) const noexcept;
        void updateToneFilters (const ReverbParams& params);
    };
}
