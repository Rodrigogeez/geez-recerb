#include "ReverbEngine.h"

namespace geez::dsp
{
    void ReverbEngine::prepare (double sr, int samplesPerBlock, int numChannels)
    {
        juce::ignoreUnused (numChannels);
        sampleRate = sr;

        for (int ch = 0; ch < 2; ++ch)
        {
            preDelayLine[ch].prepare ({ sampleRate, (juce::uint32) samplesPerBlock, 1 });
            preDelayLine[ch].setMaximumDelayInSamples ((int) std::ceil (sampleRate * 0.205)); // 200ms + margin
        }

        // Comb delay lines are sized for the largest possible modulated
        // length: base length scaled up to +50% by SIZE=100%.
        for (size_t i = 0; i < combsL.size(); ++i)
        {
            combsL[i].prepare (sampleRate, baseCombMsL[i] * 1.5f + 2.0f);
            combsR[i].prepare (sampleRate, baseCombMsR[i] * 1.5f + 2.0f);
        }
        for (size_t i = 0; i < allpassL.size(); ++i)
        {
            allpassL[i].prepare (sampleRate, allpassMsL[i]);
            allpassR[i].prepare (sampleRate, allpassMsR[i]);
        }

        juce::dsp::ProcessSpec spec { sampleRate, (juce::uint32) samplesPerBlock, 1 };
        for (int ch = 0; ch < 2; ++ch)
        {
            lowCutFilter[ch].prepare (spec);
            highCutFilter[ch].prepare (spec);
        }
        lastLowCutHz = -1.0f;
        lastHighCutHz = -1.0f;

        reset();
    }

    void ReverbEngine::reset()
    {
        for (int ch = 0; ch < 2; ++ch)
        {
            preDelayLine[ch].reset();
            lowCutFilter[ch].reset();
            highCutFilter[ch].reset();
        }
        for (auto& c : combsL) c.reset();
        for (auto& c : combsR) c.reset();
        for (auto& a : allpassL) a.reset();
        for (auto& a : allpassR) a.reset();

        for (auto& v : inputLevel)  v.store (0.0f);
        for (auto& v : outputLevel) v.store (0.0f);
    }

    float ReverbEngine::computeFeedbackForDecay (float decaySeconds, float delayMs) const noexcept
    {
        // Standard comb-filter decay-time formula: feedback such that the
        // loop attenuates by -60dB after `decaySeconds`.
        decaySeconds = std::max (0.05f, decaySeconds);
        const float loopMs = std::max (0.001f, delayMs);
        const float exponent = -3.0f * (loopMs / 1000.0f) / decaySeconds;
        float fb = std::pow (10.0f, exponent);
        return std::clamp (fb, 0.0f, 0.985f);
    }

    void ReverbEngine::updateToneFilters (const ReverbParams& params)
    {
        const bool lowChanged  = ! juce::approximatelyEqual (params.lowCutHz, lastLowCutHz);
        const bool highChanged = ! juce::approximatelyEqual (params.highCutHz, lastHighCutHz);

        if (lowChanged)
        {
            lowCutCoeffs = juce::dsp::IIR::Coefficients<float>::makeHighPass (sampleRate, params.lowCutHz);
            for (int ch = 0; ch < 2; ++ch)
                *lowCutFilter[ch].coefficients = *lowCutCoeffs;
            lastLowCutHz = params.lowCutHz;
        }
        if (highChanged)
        {
            highCutCoeffs = juce::dsp::IIR::Coefficients<float>::makeLowPass (sampleRate, params.highCutHz);
            for (int ch = 0; ch < 2; ++ch)
                *highCutFilter[ch].coefficients = *highCutCoeffs;
            lastHighCutHz = params.highCutHz;
        }
    }

    void ReverbEngine::process (juce::AudioBuffer<float>& buffer, const ReverbParams& params)
    {
        const int numSamples = buffer.getNumSamples();
        const int numChannels = buffer.getNumChannels();

        // --- Input metering (pre-processing peak) ---
        for (int ch = 0; ch < juce::jmin (2, numChannels); ++ch)
            inputLevel[(size_t) ch].store (buffer.getMagnitude (ch, 0, numSamples));

        if (params.bypassed)
        {
            for (int ch = 0; ch < juce::jmin (2, numChannels); ++ch)
                outputLevel[(size_t) ch].store (buffer.getMagnitude (ch, 0, numSamples));
            return;
        }

        updateToneFilters (params);

        const float sizeScale   = 1.0f + std::clamp (params.sizePercent, 0.0f, 100.0f) / 100.0f * 0.5f; // up to +50%
        const float damping     = std::clamp (params.dampingPct, 0.0f, 100.0f) / 100.0f;
        const float widthAmount = std::clamp (params.widthPercent, 0.0f, 150.0f) / 100.0f;
        const float mix         = std::clamp (params.mixPercent, 0.0f, 100.0f) / 100.0f;

        // Mono input is duplicated to L/R by the caller before this point,
        // so we can always treat processing as stereo internally.
        auto* left  = buffer.getWritePointer (0);
        auto* right = numChannels > 1 ? buffer.getWritePointer (1) : buffer.getWritePointer (0);

        for (int n = 0; n < numSamples; ++n)
        {
            const float dryL = left[n];
            const float dryR = right[n];

            // --- Predelay ---
            preDelayLine[0].pushSample (0, dryL);
            preDelayLine[1].pushSample (0, dryR);
            preDelayLine[0].setDelay ((float) (sampleRate * (params.preDelayMs / 1000.0)));
            preDelayLine[1].setDelay ((float) (sampleRate * (params.preDelayMs / 1000.0)));
            const float predL = preDelayLine[0].popSample (0);
            const float predR = preDelayLine[1].popSample (0);

            // --- Parallel comb bank (density + decay + damping) ---
            float wetL = 0.0f, wetR = 0.0f;
            for (size_t i = 0; i < combsL.size(); ++i)
            {
                const float dL = baseCombMsL[i] * sizeScale;
                const float dR = baseCombMsR[i] * sizeScale;
                const float fbL = computeFeedbackForDecay (params.decaySeconds, dL);
                const float fbR = computeFeedbackForDecay (params.decaySeconds, dR);
                wetL += combsL[i].process (predL, dL, fbL, damping);
                wetR += combsR[i].process (predR, dR, fbR, damping);
            }
            wetL *= 0.25f; // sum of 4 combs -> normalise
            wetR *= 0.25f;

            // --- Series allpass diffusion ---
            for (size_t i = 0; i < allpassL.size(); ++i)
            {
                wetL = allpassL[i].process (wetL, 0.5f);
                wetR = allpassR[i].process (wetR, 0.5f);
            }

            // --- Tone shaping on the wet signal only ---
            wetL = lowCutFilter[0].processSample (wetL);
            wetR = lowCutFilter[1].processSample (wetR);
            wetL = highCutFilter[0].processSample (wetL);
            wetR = highCutFilter[1].processSample (wetR);

            // --- Width (mid/side) applied to the wet signal only ---
            const float mid  = (wetL + wetR) * 0.5f;
            const float side = (wetL - wetR) * 0.5f * widthAmount;
            wetL = mid + side;
            wetR = mid - side;

            // --- Dry/Wet ---
            left[n]  = dryL * (1.0f - mix) + wetL * mix;
            right[n] = dryR * (1.0f - mix) + wetR * mix;
        }

        if (numChannels == 1)
        {
            // Mono track hosting a stereo-out bus: fold the processed R
            // back so downstream mono metering/monitoring is sane.
            for (int n = 0; n < numSamples; ++n)
                left[n] = 0.5f * (left[n] + right[n]);
        }

        for (int ch = 0; ch < juce::jmin (2, numChannels); ++ch)
            outputLevel[(size_t) ch].store (buffer.getMagnitude (ch, 0, numSamples));
    }
}
