#pragma once
#include <vector>
#include <cmath>
#include <algorithm>

namespace geez::dsp
{
    /**
        A single damped feedback comb filter.

        This is NOT used on its own as "the reverb" - it is one of eight
        filters run in parallel inside ReverbEngine, followed by a series
        of allpass diffusers. On its own a comb filter produces audible,
        periodic echoes; combining several detuned combs in parallel and
        then diffusing the result through allpass filters is what removes
        the perception of discrete echoes and produces a dense tail.

        The one-pole lowpass inside the feedback loop implements the
        DAMPING parameter: higher damping absorbs high frequencies faster
        as the tail decays, mimicking absorption in a real space.
    */
    class CombFilter
    {
    public:
        void prepare (double sampleRateIn, float maxDelayMs)
        {
            sampleRate = sampleRateIn;
            const int maxSamples = std::max (4, (int) std::ceil (sampleRate * (maxDelayMs / 1000.0)) + 4);
            buffer.assign ((size_t) maxSamples, 0.0f);
            writeIndex = 0;
            filterState = 0.0f;
            reset();
        }

        void reset()
        {
            std::fill (buffer.begin(), buffer.end(), 0.0f);
            filterState = 0.0f;
            writeIndex = 0;
        }

        // delayMs: current delay time in milliseconds (modulated by SIZE upstream)
        // feedback: 0-1, derived from DECAY
        // dampingAmount: 0-1, derived from DAMPING parameter
        float process (float input, float delayMs, float feedback, float dampingAmount)
        {
            const int delaySamples = std::clamp (
                (int) std::round (sampleRate * (delayMs / 1000.0)),
                1, (int) buffer.size() - 1);

            const int readIndex = (writeIndex - delaySamples + (int) buffer.size()) % (int) buffer.size();
            const float delayed = buffer[(size_t) readIndex];

            // One-pole lowpass in the feedback path == damping.
            filterState = delayed + dampingAmount * (filterState - delayed);

            const float toWrite = input + filterState * feedback;
            buffer[(size_t) writeIndex] = toWrite;

            writeIndex = (writeIndex + 1) % (int) buffer.size();

            return delayed;
        }

    private:
        std::vector<float> buffer;
        int writeIndex = 0;
        double sampleRate = 44100.0;
        float filterState = 0.0f;
    };
}
