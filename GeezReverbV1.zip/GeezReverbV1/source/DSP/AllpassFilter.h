#pragma once
#include <vector>
#include <cmath>
#include <algorithm>

namespace geez::dsp
{
    /**
        A single allpass diffuser.

        Chaining several of these after the parallel comb bank spreads
        the energy of each comb echo in time without colouring the
        frequency response, which is what turns "several detuned delays"
        into a smooth, dense reverberant tail.
    */
    class AllpassFilter
    {
    public:
        void prepare (double sampleRateIn, float delayMs)
        {
            sampleRate = sampleRateIn;
            const int samples = std::max (4, (int) std::round (sampleRate * (delayMs / 1000.0)));
            buffer.assign ((size_t) samples, 0.0f);
            writeIndex = 0;
        }

        void reset()
        {
            std::fill (buffer.begin(), buffer.end(), 0.0f);
            writeIndex = 0;
        }

        float process (float input, float g = 0.5f)
        {
            const float delayed = buffer[(size_t) writeIndex];
            const float bufOut = input + (-g) * delayed;
            buffer[(size_t) writeIndex] = bufOut;
            const float output = delayed + g * bufOut;

            writeIndex = (writeIndex + 1) % (int) buffer.size();
            return output;
        }

    private:
        std::vector<float> buffer;
        int writeIndex = 0;
        double sampleRate = 44100.0;
    };
}
