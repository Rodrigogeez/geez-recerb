# DEVELOPMENT.md — context for continuing this project

This file exists so a future session (human or AI) can pick this project
back up without re-deriving decisions already made.

## Status as of this writing

All 10 implementation stages from the original spec have source code
written:

1. C++/JUCE/CMake structure — done (`CMakeLists.txt`, `source/` tree)
2. Minimal VST3 plugin — done (`PluginProcessor`, `PluginEditor`)
3. Reverb engine — done (`source/DSP/ReverbEngine.*`)
4. Parameters — done (8 params + bypass, `PluginProcessor::createParameterLayout`)
5. Interface — done (`source/GUI/*`, `PluginEditor.cpp`)
6. Presets — done (`source/Presets/PresetManager.*`, 5 factory presets)
7. Standalone — done (enabled via `FORMATS VST3 Standalone` in CMakeLists)
8. GitHub Actions — done (`.github/workflows/build-windows.yml`)
9. Tests — done (`tests/PluginTests.cpp`, standalone console binary)
10. Documentation — done (this file + `README.md`)

**IMPORTANT — what has NOT been verified:** this project was written in a
Linux sandbox with no network access and no Windows/MSVC toolchain, so it
was **never actually compiled**. Everything above was written carefully
against the JUCE 7 API from memory/documentation, but the very first
thing the next session should do is run an actual build (locally on
Windows, or by pushing to trigger the GitHub Actions workflow) and fix
whatever compile errors surface. Treat this as a strong first draft, not
a verified-green build. Do not report the plugin as "working" until a
real Release build + the test suite have actually run successfully.

## Key technical decisions already made (don't re-litigate without reason)

- **JUCE version pinned to 7.0.12** via CMake `FetchContent` in
  `CMakeLists.txt`. If bumping the version, re-check `juce_add_plugin`
  argument names and `juce::dsp::DelayLine` API, which have shifted
  across JUCE major versions.
- **Reverb topology**: 4 parallel damped comb filters per channel (8
  total) → 4 series allpass filters per channel for diffusion → tone
  filters (highpass = Low Cut, lowpass = High Cut) on the wet signal
  only → mid/side width → dry/wet mix. This is a classic
  Schroeder/Moorer-style topology, implemented from scratch (see
  `source/DSP/CombFilter.h`, `AllpassFilter.h`, `ReverbEngine.cpp`) —
  not copied from any commercial or open-source plugin.
- **Stereo decorrelation**: L and R channels use *different* base delay
  lengths (`baseCombMsL` vs `baseCombMsR` in `ReverbEngine.h`), not a
  mirrored/duplicated network. This is what gives the tail a stereo
  spread instead of the L/R channels just being panned copies of one
  mono tail.
- **SIZE parameter** scales comb/allpass delay lengths up to +50% at
  100%. This was an implementation choice not fully pinned down by the
  spec (spec says "adjust coherently") — flagged here per rule 23 in
  case it needs revisiting for feel.
- **DECAY → feedback** conversion uses the standard -60dB-after-N-seconds
  comb filter formula (`ReverbEngine::computeFeedbackForDecay`).
- **Parameter IDs are final** and must not change (see comment block in
  `PluginProcessor.h`, `namespace ParamIDs`): `preDelay`, `decay`,
  `size`, `damping`, `lowCut`, `highCut`, `width`, `mix`, `bypass`.
- **Licensing** is fully isolated in `source/Licensing/LicenseManager.*`.
  It is never referenced by `ReverbEngine` or the audio path. V1 always
  reports `LicenseStatus::DevelopmentMode` / fully functional. Do not
  wire real license checks into `processBlock()` — gate the *editor* or
  a higher-level state if/when real licensing is implemented, so DSP
  code never has to know about license state.
- **No installer** yet (spec section 19) — only the raw `.vst3` +
  `.exe`, documented install path is manual copy to
  `C:\Program Files\Common Files\VST3\`.
- **AAX explicitly out of scope** for V1 (spec section 20).

## Likely first issues on a real build

These are educated guesses, not confirmed bugs — check them first:

- `juce::dsp::DelayLine` construction/`setMaximumDelayInSamples` call
  order in `ReverbEngine::prepare()` — JUCE's API here has had minor
  signature changes across versions; verify against whatever JUCE
  version actually resolves at build time.
- `juce::AudioParameterFloatAttributes` availability — this is a JUCE 7
  API; if an older JUCE resolves, parameter construction calls will need
  adjusting to the older `AudioParameterFloat` constructor form.
- `juce::dsp::IIR::Coefficients<float>::makeHighPass/makeLowPass` — these
  return a `Ptr`; double check the dereference/assignment pattern in
  `ReverbEngine::updateToneFilters()` compiles as written.
- CMake target name for the Standalone binary and VST3 bundle path used
  by the GitHub Actions workflow's "Locate VST3" / "Locate Standalone"
  steps — these use a generic recursive search specifically *because*
  the exact output folder name depends on the JUCE CMake module version;
  if the workflow fails to find the artifacts, print `build/` recursively
  in a debug step to find the actual paths and tighten the filters.

## Suggested next steps, in order

1. Run `cmake -B build` locally on Windows (or push to `main` / trigger
   the workflow manually) and fix compile errors.
2. Once it compiles, run `GeezReverbV1Tests.exe` and fix any DSP
   stability failures before touching the GUI.
3. Load the VST3 in a real DAW, confirm parameters automate, presets
   recall correctly, and bypass is truly transparent.
4. A/B against the sonic goals in section 4 of the original spec (dense,
   smooth tail; no audible discrete echoes) — this may require ear-tuning
   the comb/allpass delay-length constants in `ReverbEngine.h`, which is
   expected and fine; the topology should not need to change for that.
5. Only after V1 is confirmed stable and shipped should any of the
   explicitly-deferred features (section 10/14/20 exclusions) be
   discussed — do not add them speculatively.
