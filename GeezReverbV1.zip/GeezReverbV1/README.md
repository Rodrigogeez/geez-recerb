# Geez Reverb V1

The first plugin in the **GEEZ PLUGINS** line: a stereo algorithmic reverb.
VST3 + Standalone, Windows 64-bit.

Status: **DEVELOPMENT MODE** — fully functional, no license required (see
`source/Licensing/LicenseManager.h`).

## What it is

An original algorithmic reverb built from a parallel bank of damped comb
filters followed by a series of allpass diffusers (predelay → combs →
allpass diffusion → tone shaping → width → dry/wet). It is not a delay
with feedback labeled as reverb, and it does not copy any commercial
plugin's algorithm, code, or presets.

8 parameters, all automatable:

| Parameter  | Range          | Default |
|------------|----------------|---------|
| Pre-Delay  | 0–200 ms       | 20 ms   |
| Decay      | 0.1–10.0 s     | 2.80 s  |
| Size       | 0–100 %        | 65 %    |
| Damping    | 0–100 %        | 60 %    |
| Low Cut    | 20–500 Hz      | 100 Hz  |
| High Cut   | 2 kHz–20 kHz   | 8.00 kHz|
| Width      | 0–150 %        | 100 %   |
| Mix        | 0–100 %        | 35 %    |

Plus Bypass, stereo input/output meters, and 5 factory presets (Default,
Vocal, Room, Hall, Plate).

## Requirements to build locally

- Windows 10/11, 64-bit
- Visual Studio 2022 (Desktop development with C++ workload)
- CMake 3.22+
- Git + internet access (JUCE 7.0.12 is fetched automatically via CMake
  `FetchContent` on first configure — no manual JUCE install needed)

## Build locally

```bat
cmake -B build
cmake --build build --config Release
```

Outputs land under `build/GeezReverbV1_artefacts/Release/`:

- `VST3/Geez Reverb V1.vst3`
- `Standalone/Geez Reverb V1.exe`

(Exact subfolder naming is controlled by JUCE's CMake support and may
shift slightly between JUCE versions — check that folder if the exact
path above doesn't exist.)

## Run the Standalone

Just launch `Geez Reverb V1.exe`. It's a JUCE Standalone Plugin Host
wrapper around the same processing code as the VST3 — pick an audio
device/input/output in its device settings and play audio through it.
It is a test tool, not a DAW.

## Install the VST3

Copy the whole `Geez Reverb V1.vst3` folder to:

```
C:\Program Files\Common Files\VST3\
```

Then rescan plugins in your DAW.

## Build via GitHub Actions (recommended — this is the primary release path)

Push to `main` (or run the workflow manually via "Run workflow") and the
`.github/workflows/build-windows.yml` workflow will:

1. Spin up a `windows-latest` runner
2. Configure + build Release via CMake
3. Run the unit test suite
4. Locate the built `.vst3` and `.exe`
5. Package them with a `README.txt` into a ZIP
6. Upload the ZIP as a GitHub Actions Artifact named
   `Geez-Reverb-V1-Windows-x64`

Download that artifact from the workflow run's summary page.

## Project structure

```
GeezReverbV1/
  CMakeLists.txt
  source/
    PluginProcessor.h/.cpp   - JUCE AudioProcessor, parameters, mono/stereo handling
    PluginEditor.h/.cpp      - GUI assembly (Geez brand look)
    DSP/                     - ReverbEngine, CombFilter, AllpassFilter
    Presets/                 - PresetManager (5 factory presets)
    Licensing/               - LicenseManager stub (DEVELOPMENT MODE only)
    GUI/                     - LookAndFeel, KnobComponent, MeterComponent
  tests/PluginTests.cpp      - standalone console test suite
  .github/workflows/build-windows.yml
```

## Running tests locally

```bat
cmake -B build
cmake --build build --config Release --target GeezReverbV1Tests
build\GeezReverbV1Tests\Release\GeezReverbV1Tests.exe
```

## Not in V1 (by design)

No graphic EQ, modulation, compressor, ducking, convolution, AI features,
spectrum analyzer, AAX, licensing/serial/activation, or installer. See
`DEVELOPMENT.md` for the full rationale and what's intentionally deferred.
